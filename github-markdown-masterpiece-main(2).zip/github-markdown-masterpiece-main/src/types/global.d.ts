
interface Window {
  mermaid?: any;
  katex?: any;
  Prism?: any;
}
