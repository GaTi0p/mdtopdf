import React, { useState, useRef, useEffect } from 'react';
import MarkdownRenderer from '@/components/MarkdownRenderer';
import ThemeToggle from '@/components/ThemeToggle';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Download } from 'lucide-react';
import PdfExportPopover from "@/components/PdfExportPopover";
import { useToast } from "@/hooks/use-toast";

const DEFAULT_MARKDOWN = `# 🧬 Histoire quantique de Thiago Silva : Le défenseur interdimensionnel

![Thiago Silva](https://assets.sorare.com/playerpicture/a6d6283f-8d4c-4c14-b688-51fc03959a07/picture/squared-93342c4ecb5f0e73281a882d214a08c4.png)

\`\`\`mermaid
graph TD
    A["Naissance à Rio - 1984"] --> B["Fluminense (1998–2000)"]
    B --> C["Dynamo Moscou (2005) – interruption sanitaire"]
    C --> D["Retour à Fluminense (2006–2008)"]
    D --> E["AC Milan (2009–2012)"]
    E --> F["Paris Saint-Germain (2012–2020)"]
    F --> G["Chelsea (2020–2024)"]
    G --> H["Retour à Fluminense (2024)"]
    H --> I["Multivers Football League – à venir"]

\`\`\`

## 📊 Statistiques quantiques

| Saison       | Clubs       | Matchs | Trophées | Distorsions temporelles |
|--------------|-------------|--------|----------|-------------------------|
| 1998–2000    | Fluminense  | 50     | 1        | 0                       |
| 2009–2012    | AC Milan    | 119    | 2        | 1                       |
| 2012–2020    | PSG         | 293    | 23       | 5                       |
| 2020–2024    | Chelsea     | 155    | 3        | 2                       |
| 2024–présent | Fluminense  | 10     | 0        | 0                       |

## ➗ Mathématiques Défensives

$$
L = \\frac{T \\times S}{C}
$$

$$
D = \\sum_{i=1}^{n} \\left( \\frac{M_i}{T_i} \\right)
$$

Inline: $E = mc^2$

## 🧠 Défenseur quantique

\`\`\`mermaid
flowchart TB
    T1[Dimension Physique] -->|Force & Endurance| T3[Défenseur]
    T2[Dimension Tactique] -->|Lecture du jeu| T3
    T3 -->|Maîtrise complète| T4[Contrôle Spatio-temporel]
    T4 -->|Distorsion| T5[Multi-positionnement]
\`\`\`

## 🌐 Git multiversel de sa carrière

\`\`\`mermaid
gitGraph
    commit
    branch feature
    checkout feature
    commit
    commit
    checkout main
    merge feature
\`\`\`

## 💻 Code source : thiago_silva.cpp

\`\`\`cpp
#include <legend.h>

class ThiagoSilva : public Defender {
public:
    void intercept(Ball ball) override {
        if (ball.position == "zone_quantique") {
            activateQuantumShield();
        }
    }

private:
    void activateQuantumShield() {
        std::cout << "💥 Bouclier activé. Interception parfaite dans 4 dimensions." << std::endl;
    }
};
\`\`\`
`;

const MarkdownEditor: React.FC<{
  markdown: string;
  onChange: (value: string) => void;
}> = ({
  markdown,
  onChange
}) => {
  return <div className="border border-gray-200 dark:border-gray-700 rounded-md">
      <textarea className="w-full h-[70vh] p-4 font-mono text-sm resize-none outline-none dark:bg-gray-800 dark:text-white" value={markdown} onChange={e => onChange(e.target.value)} />
    </div>;
};

const MarkdownPreview: React.FC<{
  content: string;
  isDarkMode: boolean;
  previewRef: React.RefObject<HTMLDivElement>;
}> = ({
  content,
  isDarkMode,
  previewRef
}) => {
  return <div ref={previewRef} className={`border border-gray-200 dark:border-gray-700 rounded-md p-6 min-h-[70vh] ${isDarkMode ? 'bg-gray-900' : 'bg-white'}`}>
      <MarkdownRenderer content={content} isDarkMode={isDarkMode} />
    </div>;
};

const Controls: React.FC<{
  isDarkMode: boolean;
  toggleTheme: () => void;
  onExportPDF: (
    opts: {
      orientation: "portrait" | "landscape";
      margin: "standard" | "reduced";
      autoScaleText: boolean;
      quality: "high" | "medium" | "low";
    }
  ) => Promise<void>;
  isExporting: boolean;
  previewRef: React.RefObject<HTMLDivElement>;
}> = ({
  isDarkMode,
  toggleTheme,
  onExportPDF,
  isExporting,
  previewRef
}) => {
  return (
    <div className="flex flex-col md:flex-row justify-between items-center mb-4 gap-2">
      <div className="flex items-center gap-4">
        <TabsList>
          <TabsTrigger value="edit">Éditer</TabsTrigger>
          <TabsTrigger value="preview">Aperçu</TabsTrigger>
          <TabsTrigger value="split">Vue partagée</TabsTrigger>
        </TabsList>
        <ThemeToggle isDarkMode={isDarkMode} toggleTheme={toggleTheme} />
      </div>
      <PdfExportPopover onExport={onExportPDF} isExporting={isExporting} previewRef={previewRef} />
    </div>
  );
};

const Index = () => {
  const { toast } = useToast();
  const [markdown, setMarkdown] = useState(DEFAULT_MARKDOWN);
  const [activeTab, setActiveTab] = useState('edit');
  const [isDarkMode, setIsDarkMode] = useState(false);
  const previewRef = useRef<HTMLDivElement>(null);
  const [isExporting, setIsExporting] = useState(false);

  useEffect(() => {
    const body = document.body;
    const html = document.documentElement;
    if (isDarkMode) {
      body.classList.add('dark');
      html.classList.add('dark');
      try {
        if (typeof window !== 'undefined' && window.mermaid) {
          window.mermaid.initialize({
            theme: 'dark',
            securityLevel: 'loose'
          });
        }
      } catch (e) {
        console.error('Mermaid theme error', e);
      }
    } else {
      body.classList.remove('dark');
      html.classList.remove('dark');
      try {
        if (typeof window !== 'undefined' && window.mermaid) {
          window.mermaid.initialize({
            theme: 'default',
            securityLevel: 'loose'
          });
        }
      } catch (e) {
        console.error('Mermaid theme error', e);
      }
    }
    const renderSpecialElements = () => {
      try {
        if (typeof window !== 'undefined' && window.mermaid) {
          window.mermaid.init(undefined, document.querySelectorAll('.language-mermaid'));
        }
      } catch (e) {
        console.error('Mermaid init error', e);
      }
      if (typeof window !== 'undefined' && window.katex) {
        document.querySelectorAll('.math-block').forEach(block => {
          try {
            const content = block.textContent || '';
            if (content.trim().length > 0) {
              window.katex.render(content, block, {
                throwOnError: false,
                displayMode: true
              });
            }
          } catch (e) {
            console.error('KaTeX rendering error', e);
          }
        });
      }
      if (typeof window !== 'undefined' && window.Prism) {
        window.Prism.highlightAll();
      }
    };
    setTimeout(renderSpecialElements, 200);
  }, [isDarkMode, markdown, activeTab]);

  const toggleTheme = () => setIsDarkMode(!isDarkMode);

  const handleExportPDF = async ({
    orientation,
    margin,
    autoScaleText,
    quality
  }: {
    orientation: "portrait" | "landscape";
    margin: "standard" | "reduced";
    autoScaleText: boolean;
    quality: "high" | "medium" | "low";
  }) => {
    if (!previewRef.current) return;
    setIsExporting(true);
    try {
      const jsPDF = (await import('jspdf')).default;
      const html2canvas = (await import('html2canvas')).default;
      const pageWidth = orientation === "landscape" ? 297 : 210;
      const pageHeight = orientation === "landscape" ? 210 : 297;
      const pageFormat = "a4";
      const marginMM = margin === "standard" ? 20 : 8;
      const qualityLookup = { high: 2, medium: 1.25, low: 1 };
      const exportScale = qualityLookup[quality];
      let fontSizePct = 100;
      let canvas = await html2canvas(previewRef.current, {
        scale: exportScale,
        useCORS: true,
        logging: false,
        backgroundColor: isDarkMode ? "#0d1117" : "#fff"
      });
      let imgData = canvas.toDataURL('image/jpeg', 1.0);

      let pdf = new jsPDF({
        orientation,
        unit: 'mm',
        format: pageFormat
      });

      let imgWidth = pageWidth - 2 * marginMM;
      let imgHeight = canvas.height * imgWidth / canvas.width;

      if (orientation === "portrait" && autoScaleText && imgHeight > (pageHeight - 2 * marginMM)) {
        for (let attempt = 0; attempt < 3 && imgHeight > (pageHeight - 2 * marginMM); ++attempt) {
          fontSizePct = fontSizePct * 0.88;
          previewRef.current.style.fontSize = fontSizePct + "%";
          canvas = await html2canvas(previewRef.current, {
            scale: exportScale,
            useCORS: true,
            logging: false,
            backgroundColor: isDarkMode ? "#0d1117" : "#fff"
          });
          imgData = canvas.toDataURL('image/jpeg', 1.0);
          imgHeight = canvas.height * imgWidth / canvas.width;
        }
        previewRef.current.style.fontSize = "";
      }

      let heightLeft = imgHeight;
      let offset = marginMM;
      pdf.addImage(imgData, 'JPEG', marginMM, offset, imgWidth, imgHeight);
      heightLeft -= (pageHeight - 2 * marginMM);
      offset -= imgHeight;

      while (heightLeft > 0) {
        pdf.addPage();
        offset = (pageHeight - 2 * marginMM) - heightLeft;
        pdf.addImage(imgData, 'JPEG', marginMM, offset, imgWidth, imgHeight);
        heightLeft -= (pageHeight - 2 * marginMM);
      }

      pdf.save('markdown-export.pdf');
      toast({
        title: "Exportation réussie",
        description: "Votre PDF a été généré avec succès !",
      });
    } catch (error) {
      toast({
        title: "Erreur d’exportation",
        description: "Impossible de générer le PDF. Réessayez ou vérifiez votre configuration."
      });
      console.error('Error exporting PDF:', error);
    } finally {
      setIsExporting(false);
    }
  };

  return <div className={`container mx-auto py-8 px-4 ${isDarkMode ? 'dark' : ''}`}>
      <header className="mb-10 text-center">
        <h1 className="mb-4 font-bold text-center text-6xl">PEREIRA TIAGO</h1>
        <p className="text-xl text-gray-600 dark:text-gray-300">Éditeur et visualisateur de Markdown -&gt; PDF</p>
        <div className="mt-4 text-sm text-gray-500 dark:text-gray-400 flex justify-center space-x-4">
          <span className="flex items-center">
            <span className="inline-block w-3 h-3 bg-green-500 rounded-full mr-2"></span>
            Mermaid
          </span>
          <span className="flex items-center">
            <span className="inline-block w-3 h-3 bg-blue-500 rounded-full mr-2"></span>
            KaTeX
          </span>
          <span className="flex items-center">
            <span className="inline-block w-3 h-3 bg-purple-500 rounded-full mr-2"></span>
            Syntax Highlight
          </span>
          <span className="flex items-center">
            <span className="inline-block w-3 h-3 bg-yellow-500 rounded-full mr-2"></span>
            Export PDF
          </span>
        </div>
      </header>

      <Tabs defaultValue="edit" onValueChange={setActiveTab} className="w-full">
        <Controls
          isDarkMode={isDarkMode}
          toggleTheme={toggleTheme}
          onExportPDF={handleExportPDF}
          isExporting={isExporting}
          previewRef={previewRef}
        />
        <TabsContent value="edit" className="w-full">
          <MarkdownEditor markdown={markdown} onChange={setMarkdown} />
        </TabsContent>
        <TabsContent value="preview" className="w-full">
          <MarkdownPreview content={markdown} isDarkMode={isDarkMode} previewRef={previewRef} />
        </TabsContent>
        <TabsContent value="split" className="w-full">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <MarkdownEditor markdown={markdown} onChange={setMarkdown} />
            <MarkdownPreview content={markdown} isDarkMode={isDarkMode} previewRef={{ current: null }} />
          </div>
        </TabsContent>
      </Tabs>
    </div>;
};

export default Index;
