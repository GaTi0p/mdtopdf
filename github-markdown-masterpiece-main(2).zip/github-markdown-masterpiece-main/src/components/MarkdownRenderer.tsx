
import React, { useEffect, useRef, useState } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import remarkMath from 'remark-math';
// ⚠️ Correction : rehype-katex importé dynamiquement plus bas
import mermaid from 'mermaid';
import 'github-markdown-css/github-markdown.css';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { tomorrow, oneLight } from 'react-syntax-highlighter/dist/esm/styles/prism';

interface MarkdownRendererProps {
  content: string;
  className?: string;
  isDarkMode?: boolean;
}

// Wrapper responsive et gestion de rehype-katex dynamique pour éviter les problèmes de type
const MarkdownRenderer: React.FC<MarkdownRendererProps> = ({
  content,
  className,
  isDarkMode = false
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [rehypeKatex, setRehypeKatex] = useState<any>(null);

  useEffect(() => {
    // Chargement dynamique de rehype-katex (corrige l'erreur de type)
    import('rehype-katex').then(mod => setRehypeKatex(() => mod.default));
  }, []);

  useEffect(() => {
    mermaid.initialize({
      startOnLoad: true,
      theme: isDarkMode ? 'dark' : 'default',
      securityLevel: 'loose',
    });
    setTimeout(() => {
      try {
        if (containerRef.current) {
          const mermaidBlocks = containerRef.current.querySelectorAll('.language-mermaid');
          mermaid.init(undefined, mermaidBlocks as NodeListOf<HTMLElement>);
        }
      } catch (error) {
        console.error('Mermaid initialization error:', error);
      }
    }, 200);
  }, [content, isDarkMode]);

  // On attend que rehypeKatex soit chargé
  if (!rehypeKatex) {
    return <div className="w-full flex justify-center items-center min-h-[200px] text-gray-500">Chargement...</div>;
  }

  return (
    <div 
      ref={containerRef}
      className={`markdown-body w-full sm:w-full md:max-w-3xl lg:max-w-4xl xl:max-w-5xl mx-auto
        ${isDarkMode ? 'dark' : ''}
        overflow-auto rounded-md p-2 md:p-6 min-h-[40vh] max-h-[80vh] 
        ${className || ''}`}
      data-theme={isDarkMode ? 'dark' : 'light'}
    >
      <ReactMarkdown
        remarkPlugins={[remarkGfm, remarkMath]}
        rehypePlugins={[rehypeKatex]}
        components={{
          code({ node, inline, className, children, ...props }) {
            const match = /language-(\w+)/.exec(className || '');
            if (match && match[1] === 'mermaid') {
              return (
                <pre className="language-mermaid text-base sm:text-base md:text-lg" style={{ textAlign: 'center' }}>
                  {String(children).replace(/\n$/, '')}
                </pre>
              );
            }
            if (!inline && match) {
              return (
                <SyntaxHighlighter
                  style={isDarkMode ? tomorrow : oneLight}
                  language={match[1]}
                  PreTag="div"
                  customStyle={{ 
                    background: isDarkMode ? '#1e1e1e' : '#f6f8fa',
                    borderRadius: '6px',
                    padding: '16px',
                    margin: '1em 0',
                    fontSize: '1rem',
                    overflowX: 'auto'
                  }}
                  {...props}
                >
                  {String(children).replace(/\n$/, '')}
                </SyntaxHighlighter>
              );
            }
            return (
              <code className={className + ' bg-muted px-1 rounded'} {...props}>
                {children}
              </code>
            );
          },
          li({ node, className, children, ...props }) {
            if (
              node.children[0] &&
              node.children[0].type === 'element' &&
              node.children[0].tagName === 'input'
            ) {
              const checked = node.children[0].properties?.checked;
              return (
                <li className={`task-list-item ${className || ''}`} {...props}>
                  <input type="checkbox" checked={!!checked} readOnly /> {children}
                </li>
              );
            }
            return <li {...props}>{children}</li>;
          },
          blockquote({ node, children, ...props }) {
            const firstChild = node.children[0];
            if (
              firstChild &&
              firstChild.type === 'element' &&
              firstChild.children[0] &&
              firstChild.children[0].type === 'text'
            ) {
              const text = firstChild.children[0].value || '';
              if (text.startsWith('[!NOTE]') || text.startsWith('[!WARNING]')) {
                const type = text.includes('NOTE') ? 'note' : 'warning';
                const title = type === 'note' ? 'Note' : 'Attention';
                return (
                  <div className={`admonition admonition-${type}`}>
                    <div className="admonition-heading">{title}</div>
                    <div className="admonition-content">{children}</div>
                  </div>
                );
              }
            }
            return <blockquote {...props}>{children}</blockquote>;
          },
        }}
      >
        {content}
      </ReactMarkdown>
    </div>
  );
};

export default MarkdownRenderer;

