
import React, { useState } from "react";
import { Popover, PopoverTrigger, PopoverContent } from "@/components/ui/popover";
import { Button } from "@/components/ui/button";
import { Settings, FilePlus, Maximize, Download, CircleCheck } from "lucide-react";
import { Switch } from "@radix-ui/react-switch";
import { Label } from "@/components/ui/label";

const PDF_QUALITIES = [
  { value: "high", label: "Haute" },
  { value: "medium", label: "Moyenne" },
  { value: "low", label: "Basse" },
];

const PDF_ORIENTATIONS = [
  { value: "portrait", label: "Portrait" },
  { value: "landscape", label: "Paysage" },
];

const PDF_MARGES = [
  { value: "standard", label: "Standard" },
  { value: "reduced", label: "Réduite" },
];

interface PdfExportPopoverProps {
  onExport: (
    opts: {
      orientation: "portrait" | "landscape";
      margin: "standard" | "reduced";
      autoScaleText: boolean;
      quality: "high" | "medium" | "low";
    }
  ) => Promise<void>;
  isExporting: boolean;
  previewRef: React.RefObject<HTMLDivElement>;
}

export const PdfExportPopover: React.FC<PdfExportPopoverProps> = ({
  onExport,
  isExporting,
  previewRef
}) => {
  const [orientation, setOrientation] = useState<"portrait" | "landscape">("portrait");
  const [margin, setMargin] = useState<"standard" | "reduced">("standard");
  const [autoScaleText, setAutoScaleText] = useState<boolean>(true);
  const [quality, setQuality] = useState<"high" | "medium" | "low">("high");
  const [popoverOpen, setPopoverOpen] = useState(false);
  const [exportOk, setExportOk] = useState(false);

  const exportingAnimClass = isExporting ? "animate-pulse scale-105" : "";
  const handleExport = async () => {
    setExportOk(false);
    await onExport({
      orientation,
      margin,
      autoScaleText,
      quality,
    });
    setExportOk(true);
    setTimeout(() => setExportOk(false), 1800);
    setPopoverOpen(false);
  };

  return (
    <Popover open={popoverOpen} onOpenChange={setPopoverOpen}>
      <PopoverTrigger asChild>
        <Button
          className={`bg-blue-600 hover:bg-blue-700 text-white flex items-center gap-2 rounded-lg px-4 py-2 transition-all duration-150 shadow ${exportingAnimClass}`}
          aria-label="Paramètres PDF"
        >
          <Settings size={18} />
          Exporter en PDF
        </Button>
      </PopoverTrigger>
      <PopoverContent align="end" className="min-w-[310px] max-w-full glass-morphism shadow-xl animate-scale-in">
        <div className="space-y-2">
          <div className="flex items-center gap-2 mb-2">
            <FilePlus size={20} className="text-blue-500" />
            <div className="font-bold text-lg">Exporter vers PDF</div>
          </div>
          <div className="space-y-1">
            <Label className="text-xs mb-1">Orientation</Label>
            <div className="flex gap-2">
              {PDF_ORIENTATIONS.map(opt => (
                <Button key={opt.value}
                  className={`flex-1 ${orientation === opt.value ? "bg-blue-100 text-blue-700" : "bg-gray-50 hover:bg-gray-200"}`}
                  variant="ghost"
                  size="sm"
                  type="button"
                  onClick={() => setOrientation(opt.value as any)}
                >
                  {opt.label}
                </Button>
              ))}
            </div>
          </div>
          <div className="space-y-1">
            <Label className="text-xs mb-1">Marge</Label>
            <div className="flex gap-2">
              {PDF_MARGES.map(opt => (
                <Button key={opt.value}
                  className={`flex-1 ${margin === opt.value ? "bg-blue-100 text-blue-700" : "bg-gray-50 hover:bg-gray-200"}`}
                  variant="ghost"
                  size="sm"
                  type="button"
                  onClick={() => setMargin(opt.value as any)}
                >
                  {opt.label}
                </Button>
              ))}
            </div>
          </div>
          <div className="flex items-center justify-between mt-1">
            <Label className="text-xs">Réduction auto texte</Label>
            <Switch
              checked={autoScaleText}
              onCheckedChange={setAutoScaleText}
              className="bg-gray-200 data-[state=checked]:bg-blue-400 transition-transform"
              aria-label="Réduction du texte auto"
            />
          </div>
          <div className="space-y-1">
            <Label className="text-xs mb-1">Qualité d’exportation</Label>
            <div className="flex gap-2">
              {PDF_QUALITIES.map(opt => (
                <Button key={opt.value}
                  className={`flex-1 ${quality === opt.value ? "bg-blue-100 text-blue-700" : "bg-gray-50 hover:bg-gray-200"}`}
                  variant="ghost"
                  size="sm"
                  type="button"
                  onClick={() => setQuality(opt.value as any)}
                >
                  {opt.label}
                </Button>
              ))}
            </div>
          </div>
          <div className="pt-2 flex flex-col gap-2">
            <Button
              className={`bg-gradient-to-r from-blue-500 to-blue-600 text-white font-bold flex items-center justify-center gap-2 rounded-lg transition-all duration-150 hover:scale-105 hover:shadow-md shadow-blue-200 relative disabled:opacity-50 ${isExporting ? "pointer-events-none" : ""}`}
              size="lg"
              onClick={handleExport}
              disabled={isExporting}
              type="button"
            >
              <Download className="h-5 w-5" />
              {isExporting ? "Exportation..." : "Exporter en PDF"}
              {exportOk && (
                <CircleCheck className="ml-2 text-green-500 animate-scale-in" size={18} aria-label="Succès" />
              )}
            </Button>
          </div>
          <p className="text-xs text-gray-500 pt-2">Un aperçu en temps réel est affiché à droite.<br/>Configurez les options, puis cliquez sur "Exporter".</p>
        </div>
      </PopoverContent>
    </Popover>
  );
};

export default PdfExportPopover;

