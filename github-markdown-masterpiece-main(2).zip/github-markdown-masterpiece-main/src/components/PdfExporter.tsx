
import React from 'react';
import { Button } from '@/components/ui/button';

interface PdfExporterProps {
  targetRef: React.RefObject<HTMLElement>;
  fileName?: string;
  onExport: () => void;
}

const PdfExporter: React.FC<PdfExporterProps> = ({ 
  onExport,
  fileName = 'markdown-export.pdf' 
}) => {
  return (
    <Button 
      onClick={onExport}
      className="bg-blue-600 hover:bg-blue-700 text-white"
    >
      Exporter en PDF
    </Button>
  );
};

export default PdfExporter;
