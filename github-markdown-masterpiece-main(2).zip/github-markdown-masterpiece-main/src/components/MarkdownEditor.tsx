
import React, { useState } from 'react';
import MDEditor from '@uiw/react-md-editor';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface MarkdownEditorProps {
  initialValue?: string;
  onChange?: (value: string) => void;
  className?: string;
}

const MarkdownEditor: React.FC<MarkdownEditorProps> = ({
  initialValue = '',
  onChange,
  className,
}) => {
  const [value, setValue] = useState<string>(initialValue);

  const handleChange = (val: string | undefined) => {
    const newValue = val || '';
    setValue(newValue);
    if (onChange) {
      onChange(newValue);
    }
  };

  return (
    <div className={cn("w-full", className)}>
      <MDEditor
        value={value}
        onChange={handleChange}
        preview="edit"
        height={500}
        className="github-markdown-editor"
        textareaProps={{
          placeholder: "Écrivez votre markdown ici...",
        }}
      />
      <div className="flex justify-end mt-4 space-x-2">
        <Button variant="outline" onClick={() => setValue('')}>
          Effacer
        </Button>
        <Button onClick={() => navigator.clipboard.writeText(value)}>
          Copier
        </Button>
      </div>
    </div>
  );
};

export default MarkdownEditor;
