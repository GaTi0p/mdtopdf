- [x] Analyser les documents fournis et comprendre les exigences
- [x] Rechercher des informations complémentaires sur les technologies et standards
- [x] Concevoir l'architecture et les spécifications techniques détaillées
- [x] Rédiger le prompt complet en Markdown avec spécifications détaillées
- [x] Convertir les spécifications en formats JSON et CSV
- [x] Livrer les documents finaux à l'utilisateur

